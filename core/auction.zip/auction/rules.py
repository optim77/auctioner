from auction.models import AuctionStatus as S


class InvalidAuctionTransaction(Exception):
    pass


ALLOWED = {
    S.DRAFT: {S.DRAFT},
    S.ACTIVE: {S.ACTIVE},
    S.SOLD: set(),
    S.EXPIRED: set(),
}


def ensure_transition(current: str, target: str):
    if target not in ALLOWED[current]:
        raise InvalidAuctionTransaction(f"{current} -> {target}")
