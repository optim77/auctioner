from rest_framework import generics, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication
from users.permissions.permissions_utils import IsOwnerOfAuction

from auction.models import Auction
from auction.selectors import (
    get_hot_auctions,
    newest_auction,
    newest_auction_in_category,
    search_auction,
)
from auction.serializers import AuctionSerializer
from auction.services import AuctionServices


class AuctionViewSet(viewsets.ModelViewSet):
    queryset = Auction.objects.all()
    serializer_class = AuctionSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsOwnerOfAuction]
    lookup_field = 'id'

    def get_queryset(self):
        if self.action != "list":
            return Auction.objects.all()
        search = self.request.query_params.get("q")
        return search_auction(search) if search else Auction.objects.is_active()

    @action(detail=True, methods=["post"])
    def activate(self, request, id=None) -> Response:
        auction = self.get_object()
        auction = AuctionServices.activate(auction.id)
        return Response(AuctionSerializer(auction).data, status=status.HTTP_200_OK)

    @action(detail=True, methods=['post'])
    def finish(self, request, id=None) -> Response:
        auction = self.get_object()
        auction = AuctionServices.finish(auction.id)
        return Response(
            AuctionSerializer(auction).data, status=status.HTTP_200_OK
        )

    @action(detail=True, methods=['post'])
    def expire(self, request, id=None) -> Response:
        auction = self.get_object()
        auction = AuctionServices.expire(auction.id)
        return Response(
            AuctionSerializer(auction).data, status=status.HTTP_200_OK
        )

class NewestAuctionViewSet(generics.ListAPIView):
    serializer_class = AuctionSerializer

    def get_queryset(self):
        return newest_auction()


class NewestInCategoryViewSet(generics.ListAPIView):
    serializer_class = AuctionSerializer

    def get_queryset(self):
        category = self.request.query_params.get("category")
        return  newest_auction_in_category(category=category) if category else Auction.objects.none()


class HotAuctionViewSet(generics.ListAPIView):
    serializer_class  = AuctionSerializer

    def get_queryset(self):
        return get_hot_auctions()

